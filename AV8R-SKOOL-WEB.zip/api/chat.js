const MODEL_DEFAULT = 'gemini-3.8-flash';

const SYSTEM = `Eres AV8R Guide, el asistente bilingüe de AV8R School.
Ayudas a personas interesadas en el FAA A&P, aviación ejecutiva, cursos, comunidad y siguiente paso.
Reglas:
- Responde en el idioma del usuario (español o inglés), breve y claro (máximo 120 palabras).
- No inventes precios, fechas, disponibilidad, plazos, visas, empleos ni aprobaciones FAA.
- La FAA emite el certificado A&P; AV8R prepara y acompaña. El A&P no otorga autorización de trabajo en EE. UU.
- La práctica y el oral/practical requieren partner/DME autorizado.
- EASA Part 66 es distinto; no lo presentes como equivalente automático.
- Datos técnicos de aeronaves de lujo pueden estar sujetos a ITAR/EAR; no des asesoría legal.
- Si falta un dato, deriva a un asesor humano o a https://www.skool.com/av8rschool.
- No prometas resultados, empleo, visa ni certificación.`;

module.exports = async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'method_not_allowed' });
    return;
  }

  const apiKey = (process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY || '').trim();
  if (!apiKey) {
    res.status(503).json({ error: 'missing_api_key' });
    return;
  }

  const model = (process.env.GEMINI_MODEL || MODEL_DEFAULT).trim();
  const body = req.body || {};
  const messages = Array.isArray(body.messages) ? body.messages.slice(-10) : [];

  const contents = messages
    .filter(m => m && typeof m.content === 'string' && m.content.trim())
    .map(m => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content.trim().slice(0, 1200) }]
    }));

  if (!contents.length) {
    res.status(400).json({ error: 'empty_conversation' });
    return;
  }

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-goog-api-key': apiKey
        },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: SYSTEM }] },
          contents,
          generationConfig: { temperature: 0.55, maxOutputTokens: 420 }
        })
      }
    );

    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const code = data && data.error && data.error.code ? `gemini_${data.error.code}` : `gemini_${response.status}`;
      console.error('[api/av8r]', code, data && data.error && data.error.message);
      res.status(503).json({ error: 'ai_unavailable', code });
      return;
    }

    const text = (data.candidates || [])
      .flatMap(c => (c.content && c.content.parts) || [])
      .map(p => p.text || '')
      .join('\n')
      .trim();

    if (!text) {
      res.status(503).json({ error: 'empty_reply' });
      return;
    }

    res.status(200).json({ reply: text, model });
  } catch (error) {
    console.error('[api/av8r] request_failed', error && error.message);
    res.status(503).json({ error: 'ai_unavailable' });
  }
};
