/* ==========================================================================
   AV8R School · prototipo de portal
   - i18n ES/EN
   - programas, ruta y FAQ dinámicos
   - AV8R Guide: API Gemini opcional + fallback local
   ========================================================================== */
(() => {
  'use strict';

  const CONFIG = {
    email: 'hello@av8rschool.com',
    skool: 'https://www.skool.com/av8rschool',
    api: '/api/chat'
  };

  const $ = (s, c = document) => c.querySelector(s);
  const $$ = (s, c = document) => Array.from(c.querySelectorAll(s));
  const state = { lang: 'es', filter: 'all', chatLang: 'es', chatStarted: false, chatBusy: false };
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  /* ------------------------------------------------------------------
     i18n
     ------------------------------------------------------------------ */
  const I18N = {
    es: {
      'nav.path': 'Ruta', 'nav.programs': 'Programas', 'nav.community': 'Comunidad', 'nav.alliances': 'Alianzas', 'nav.faq': 'FAQ', 'nav.apply': 'Aplicar',
      'hero.eyebrow': 'FAA A&P · Aviación ejecutiva · EN/ES',
      'hero.title': 'De cero a <span class="accent">A&amp;P</span>.<br>De A&amp;P a la <span class="accent">aviación ejecutiva</span>.',
      'hero.lead': 'Una ruta bilingüe para entrar, crecer y destacar en aviación corporativa. Teoría, práctica, mentoría y alianzas con la industria. Sin atajos y sin promesas vacías.',
      'hero.cta1': 'Empezar mi ruta', 'hero.cta2': 'Hablar con AV8R',
      'hero.trust1': 'Ruta FAA A&P', 'hero.trust2': 'Bilingüe ES/EN', 'hero.trust3': 'Alianzas OEM', 'hero.trust4': '391 en comunidad',
      'start.kicker': 'Punto de partida',
      'start.title': 'No todos empiezan<br><em>en el mismo punto.</em>',
      'start.lead': 'Elige dónde estás hoy. AV8R ajusta la ruta, el inglés y la práctica a tu caso.',
      'start.card1': 'Estoy empezando', 'start.card1s': 'Quiero entrar a aviación desde cero.',
      'start.card2': 'Tengo experiencia', 'start.card2s': 'Ya trabajo en mantenimiento o talleres.',
      'start.card3': 'Ya soy A&P', 'start.card3s': 'Quiero aviación ejecutiva u OEM.',
      'start.card4': 'Soy empleador', 'start.card4s': 'Busco talento técnico bilingüe.',
      'path.kicker': 'La ruta', 'path.title': 'Una ruta.<br><em>Cinco etapas.</em>',
      'path.lead': 'No es un curso suelto. Es un plan con diagnóstico, teoría, práctica, examen y empleo. Cada etapa tiene un entregable claro.',
      'path.note': 'La FAA certifica al técnico. AV8R prepara, acompaña y conecta con práctica y empleadores.',
      'path.cta': 'Ver programas',
      'programs.kicker': 'Programas', 'programs.title': 'Cursos para cada etapa.<br><em>No para todos.</em>',
      'programs.lead': 'Elige por etapa, no por catálogo. La malla exacta, la duración y el precio se confirman con AV8R según tu cohorte y país.',
      'programs.all': 'Todos', 'programs.ap': 'A&P', 'programs.english': 'Inglés', 'programs.oem': 'OEM', 'programs.career': 'Empleo',
      'programs.note': 'No publicamos precios ni fechas que no estén confirmados. Si un dato no está, se pide por el chat o en la comunidad.',
      'faa.kicker': 'Estándar FAA', 'faa.title': 'La FAA no regala el título.<br><em>Y nosotros no lo vendemos.</em>',
      'faa.lead': 'El A&P se gana con experiencia, estudio y exámenes. AV8R te prepara y te acompaña; la certificación la emite la FAA.',
      'faa.req1': '18 años y dominio del inglés (leer, escribir, hablar y entender).',
      'faa.req2': '18 meses de experiencia por rating o 30 meses para A&P; o escuela Part 147.',
      'faa.req3': 'Examen written, oral y practical con DME autorizado.',
      'faa.req4': 'Práctica supervisada y logbook; no se reemplaza con video.',
      'faa.source': 'Fuente',
      'faa.cta': 'Revisar mi elegibilidad',
      'faa.cardTitle': 'La verdad incómoda',
      'faa.card1': 'El certificado A&P no otorga visa ni autorización de trabajo en EE. UU.',
      'faa.card2': 'La práctica y el oral/practical se hacen con un partner o DME; no los simulamos como oficiales.',
      'faa.card3': 'Los datos técnicos de aeronaves de lujo pueden estar sujetos a ITAR/EAR. El acceso de extranjeros requiere revisión legal.',
      'community.kicker': 'Comunidad', 'community.title': 'No caminas solo.<br><em>Entras a una tripulación.</em>',
      'community.lead': 'AV8R School nació como comunidad: estudio, mentoría, guías FAST TRACK en inglés y español, y acceso a beneficios OEM. La plataforma es el aula; la comunidad es el equipo.',
      'community.cta': 'Entrar a Skool',
      'community.stat1': 'miembros', 'community.stat2': 'cursos', 'community.stat3': 'módulos', 'community.stat4': 'años de experiencia',
      'community.inside1': 'Sistema de estudio A&P y guías FAST TRACK EN/ES.',
      'community.inside2': 'Mentoría y preguntas de técnicos que ya están en la industria.',
      'community.inside3': 'Beneficios OEM y descuentos en factory training.',
      'community.inside4': 'Calendario, eventos y red de contactos.',
      'community.founder': 'FOUNDER',
      'community.founderBio': 'USAF veteran · FAA-certified aircraft mechanic · 25+ years in business and commercial aviation.',
      'community.founderCta': 'Conocer su historia',
      'alliances.kicker': 'Alianzas', 'alliances.title': 'La ruta no termina<br><em>en el examen.</em>',
      'alliances.lead': 'Para trabajar en aviación ejecutiva hacen falta práctica, empleadores y cumplimiento. AV8R construye el puente, no promete el puesto.',
      'alliances.a1': 'Escuelas aprobadas para práctica y elegibilidad académica.',
      'alliances.a2': 'Talleres de reparación para OJT, práctica y empleo.',
      'alliances.a3': 'Gulfstream, Bombardier, Dassault, Embraer y Textron: formación de tipo y especialización.',
      'alliances.a4': 'FBOs, flight departments y recruiters que buscan talento bilingüe.',
      'alliances.note': 'Visas, autorización de trabajo y relocation se gestionan con abogado de inmigración. No prometemos empleo ni visa.',
      'assistant.kicker': 'AV8R Guide', 'assistant.title': 'Pregunta lo que<br><em>no está en la página.</em>',
      'assistant.lead': 'Un asistente bilingüe para orientarte sobre la ruta FAA, los cursos, la comunidad y el siguiente paso. No reemplaza a un asesor humano ni a la FAA.',
      'faq.kicker': 'Preguntas', 'faq.title': 'Antes de<br><em>subir a bordo.</em>',
      'faq.lead': 'Lo que suelen preguntar antes de empezar. Si falta algo, el chat está abierto.',
      'faq.cta': 'Hacer una pregunta',
      'apply.kicker': 'Siguiente paso', 'apply.title': 'Tu ruta empieza<br><em>con una conversación.</em>',
      'apply.lead': 'Cuéntanos dónde estás y qué quieres lograr. Te orientamos sobre la ruta, la comunidad y los siguientes pasos. Sin promesas de visa ni de empleo.',
      'form.name': 'Nombre', 'form.namePh': 'Tu nombre',
      'form.email': 'Correo', 'form.emailPh': 'tu@correo.com',
      'form.country': 'País', 'form.countryPh': 'Colombia / US',
      'form.goal': 'Objetivo', 'form.goalStart': 'Empezar de cero', 'form.goalExp': 'Tengo experiencia', 'form.goalAp': 'Ya soy A&P', 'form.goalEmp': 'Soy empleador',
      'form.message': '¿Qué quieres lograr?', 'form.messagePh': 'Cuéntanos en una frase...',
      'form.consent': 'Autorizo el tratamiento de mis datos para que AV8R me contacte. Entiendo que AV8R no certifica ni garantiza visas o empleo.',
      'form.submit': 'Enviar solicitud',
      'form.note': 'Este prototipo abre un correo prellenado. La versión de producción debe conectar CRM y consentimiento.',
      'mobile.path': 'Ruta', 'mobile.courses': 'Cursos', 'mobile.chat': 'Chat',
      'chat.placeholder': 'Escribe tu pregunta...',
      'chat.legal': 'Asistente informativo. No es la FAA ni un asesor migratorio. <a href="https://www.skool.com/av8rschool" target="_blank" rel="noopener">Hablar con AV8R</a>.',
      'chat.welcome': 'Hola. Soy AV8R Guide. Te ayudo a ubicar tu ruta FAA A&P, los cursos y el siguiente paso. ¿Estás empezando, ya tienes experiencia o buscas talento?',
      'chat.quick1': 'Ruta FAA', 'chat.quick2': 'Cursos', 'chat.quick3': 'Empleo', 'chat.quick4': 'Hablar con humano',
      'chat.typing': 'AV8R Guide está escribiendo…',
      'chat.langChanged': 'Ahora respondo en español.',
      'form.sending': 'Abriendo tu correo con la solicitud…',
      'form.error': 'Revisa nombre, correo y consentimiento.',
      'form.ok': 'Solicitud preparada. Completa el envío en tu correo.'
    },
    en: {
      'nav.path': 'Path', 'nav.programs': 'Programs', 'nav.community': 'Community', 'nav.alliances': 'Alliances', 'nav.faq': 'FAQ', 'nav.apply': 'Apply',
      'hero.eyebrow': 'FAA A&P · Business aviation · EN/ES',
      'hero.title': 'From zero to <span class="accent">A&amp;P</span>.<br>From A&amp;P to <span class="accent">business aviation</span>.',
      'hero.lead': 'A bilingual pathway to enter, grow and stand out in corporate aviation. Theory, practice, mentorship and industry alliances. No shortcuts, no empty promises.',
      'hero.cta1': 'Start my path', 'hero.cta2': 'Talk to AV8R',
      'hero.trust1': 'FAA A&P pathway', 'hero.trust2': 'Bilingual ES/EN', 'hero.trust3': 'OEM alliances', 'hero.trust4': '391 in community',
      'start.kicker': 'Starting point',
      'start.title': 'Not everyone starts<br><em>at the same point.</em>',
      'start.lead': 'Choose where you are today. AV8R adjusts the path, English and practice to your case.',
      'start.card1': 'I am starting', 'start.card1s': 'I want to enter aviation from zero.',
      'start.card2': 'I have experience', 'start.card2s': 'I already work in maintenance or a shop.',
      'start.card3': 'I am A&P', 'start.card3s': 'I want business aviation or OEM.',
      'start.card4': 'I am an employer', 'start.card4s': 'I am looking for bilingual technical talent.',
      'path.kicker': 'The path', 'path.title': 'One path.<br><em>Five stages.</em>',
      'path.lead': 'It is not a loose course. It is a plan with diagnosis, theory, practice, testing and employment. Each stage has a clear deliverable.',
      'path.note': 'The FAA certifies the technician. AV8R prepares, supports and connects you with practice and employers.',
      'path.cta': 'See programs',
      'programs.kicker': 'Programs', 'programs.title': 'Courses for each stage.<br><em>Not for everyone.</em>',
      'programs.lead': 'Choose by stage, not by catalog. The exact curriculum, duration and price are confirmed with AV8R for your cohort and country.',
      'programs.all': 'All', 'programs.ap': 'A&P', 'programs.english': 'English', 'programs.oem': 'OEM', 'programs.career': 'Career',
      'programs.note': 'We do not publish prices or dates that are not confirmed. If a data point is missing, ask in chat or in the community.',
      'faa.kicker': 'FAA standard', 'faa.title': 'The FAA does not give the certificate away.<br><em>And we do not sell it.</em>',
      'faa.lead': 'The A&P is earned with experience, study and tests. AV8R prepares and supports you; the FAA issues the certificate.',
      'faa.req1': '18 years old and English proficiency (read, write, speak and understand).',
      'faa.req2': '18 months of experience per rating or 30 months for A&P; or a Part 147 school.',
      'faa.req3': 'Written, oral and practical tests with an authorized DME.',
      'faa.req4': 'Supervised practice and logbook; video does not replace it.',
      'faa.source': 'Source',
      'faa.cta': 'Check my eligibility',
      'faa.cardTitle': 'The uncomfortable truth',
      'faa.card1': 'An A&P certificate does not grant a visa or work authorization in the U.S.',
      'faa.card2': 'Practice and the oral/practical are done with a partner or DME; we do not simulate them as official.',
      'faa.card3': 'Technical data on luxury aircraft may be subject to ITAR/EAR. Foreign national access requires legal review.',
      'community.kicker': 'Community', 'community.title': 'You do not walk alone.<br><em>You join a crew.</em>',
      'community.lead': 'AV8R School was born as a community: study, mentorship, FAST TRACK guides in English and Spanish, and access to OEM benefits. The platform is the classroom; the community is the crew.',
      'community.cta': 'Join Skool',
      'community.stat1': 'members', 'community.stat2': 'courses', 'community.stat3': 'modules', 'community.stat4': 'years of experience',
      'community.inside1': 'A&P study system and FAST TRACK guides EN/ES.',
      'community.inside2': 'Mentorship and questions from technicians already in the industry.',
      'community.inside3': 'OEM benefits and factory training discounts.',
      'community.inside4': 'Calendar, events and networking.',
      'community.founder': 'FOUNDER',
      'community.founderBio': 'USAF veteran · FAA-certified aircraft mechanic · 25+ years in business and commercial aviation.',
      'community.founderCta': 'Read his story',
      'alliances.kicker': 'Alliances', 'alliances.title': 'The path does not end<br><em>at the test.</em>',
      'alliances.lead': 'Working in business aviation requires practice, employers and compliance. AV8R builds the bridge; it does not promise the job.',
      'alliances.a1': 'Approved schools for practice and academic eligibility.',
      'alliances.a2': 'Repair stations for OJT, practice and employment.',
      'alliances.a3': 'Gulfstream, Bombardier, Dassault, Embraer and Textron: type training and specialization.',
      'alliances.a4': 'FBOs, flight departments and recruiters looking for bilingual talent.',
      'alliances.note': 'Visas, work authorization and relocation are handled with an immigration attorney. We do not promise employment or a visa.',
      'assistant.kicker': 'AV8R Guide', 'assistant.title': 'Ask what is<br><em>not on the page.</em>',
      'assistant.lead': 'A bilingual assistant to guide you on the FAA path, courses, community and next step. It does not replace a human advisor or the FAA.',
      'faq.kicker': 'Questions', 'faq.title': 'Before you<br><em>board.</em>',
      'faq.lead': 'What people usually ask before starting. If something is missing, the chat is open.',
      'faq.cta': 'Ask a question',
      'apply.kicker': 'Next step', 'apply.title': 'Your path starts<br><em>with a conversation.</em>',
      'apply.lead': 'Tell us where you are and what you want to achieve. We will guide you on the path, the community and next steps. No visa or job promises.',
      'form.name': 'Name', 'form.namePh': 'Your name',
      'form.email': 'Email', 'form.emailPh': 'you@email.com',
      'form.country': 'Country', 'form.countryPh': 'Colombia / US',
      'form.goal': 'Goal', 'form.goalStart': 'Start from zero', 'form.goalExp': 'I have experience', 'form.goalAp': 'I am A&P', 'form.goalEmp': 'I am an employer',
      'form.message': 'What do you want to achieve?', 'form.messagePh': 'Tell us in one sentence...',
      'form.consent': 'I consent to AV8R contacting me about my request. I understand AV8R does not certify or guarantee visas or employment.',
      'form.submit': 'Send application',
      'form.note': 'This prototype opens a pre-filled email. Production should connect a CRM and consent tracking.',
      'mobile.path': 'Path', 'mobile.courses': 'Courses', 'mobile.chat': 'Chat',
      'chat.placeholder': 'Type your question...',
      'chat.legal': 'Informational assistant. Not the FAA or an immigration advisor. <a href="https://www.skool.com/av8rschool" target="_blank" rel="noopener">Talk to AV8R</a>.',
      'chat.welcome': 'Hi. I am AV8R Guide. I help you locate your FAA A&P path, courses and next step. Are you starting, do you have experience, or are you looking for talent?',
      'chat.quick1': 'FAA path', 'chat.quick2': 'Courses', 'chat.quick3': 'Jobs', 'chat.quick4': 'Talk to a human',
      'chat.typing': 'AV8R Guide is typing…',
      'chat.langChanged': 'I will reply in English now.',
      'form.sending': 'Opening your email with the application…',
      'form.error': 'Check name, email and consent.',
      'form.ok': 'Application prepared. Complete the send in your email.'
    }
  };

  const t = (key, lang = state.lang) => (I18N[lang] && I18N[lang][key]) || (I18N.es[key] || '');

  /* ------------------------------------------------------------------
     Data
     ------------------------------------------------------------------ */
  const ROUTE = [
    { n: '01', es: ['Diagnóstico + inglés', 'Revisamos edad, inglés, experiencia, país y objetivo. Nivelamos lo que falte antes de entrar a teoría.'], en: ['Diagnosis + English', 'We review age, English, experience, country and goal. We level what is missing before theory.'], out: { es: 'Plan personal', en: 'Personal plan' } },
    { n: '02', es: ['A&P General', 'Fundamentos, regulaciones, matemáticas, física, materiales y seguridad. Base para todos los ratings.'], en: ['A&P General', 'Fundamentals, regulations, math, physics, materials and safety. The base for every rating.'], out: { es: 'Examen General', en: 'General test' } },
    { n: '03', es: ['Airframe + Powerplant', 'Estructuras, sistemas, motores y hélices. Teoría con práctica y proyectos.'], en: ['Airframe + Powerplant', 'Structures, systems, engines and propellers. Theory with practice and projects.'], out: { es: 'Proyectos y mocks', en: 'Projects and mocks' } },
    { n: '04', es: ['Práctica + Testing', 'Partner Part 147/145, logbook, PSI written y DME oral/practical. Sin simular lo oficial.'], en: ['Practice + Testing', 'Part 147/145 partner, logbook, PSI written and DME oral/practical. No faking the official.'], out: { es: 'Readiness real', en: 'Real readiness' } },
    { n: '05', es: ['OEM + Empleo', 'Aviación ejecutiva, portafolio, entrevistas y alianzas con empleadores. La visa se gestiona aparte.'], en: ['OEM + Employment', 'Business aviation, portfolio, interviews and employer alliances. Visa is handled separately.'], out: { es: 'Carrera', en: 'Career' } }
  ];

  const PROGRAMS = [
    { cat: 'ap', tag: { es: 'A&P · Nivel 1', en: 'A&P · Level 1' }, title: { es: 'A&P General', en: 'A&P General' }, desc: { es: 'Fundamentos, regulaciones, matemáticas, física, materiales y seguridad.', en: 'Fundamentals, regulations, math, physics, materials and safety.' }, meta: { es: 'Online · mentoría · quiz', en: 'Online · mentor · quiz' } },
    { cat: 'ap', tag: { es: 'A&P · Nivel 2', en: 'A&P · Level 2' }, title: { es: 'Airframe', en: 'Airframe' }, desc: { es: 'Estructuras, hidráulica, neumática, eléctrico y sistemas de la aeronave.', en: 'Structures, hydraulics, pneumatics, electrical and aircraft systems.' }, meta: { es: 'Video · práctica · mock', en: 'Video · practice · mock' } },
    { cat: 'ap', tag: { es: 'A&P · Nivel 3', en: 'A&P · Level 3' }, title: { es: 'Powerplant', en: 'Powerplant' }, desc: { es: 'Motores, hélices, combustible, ignición y sistemas de potencia.', en: 'Engines, propellers, fuel, ignition and powerplant systems.' }, meta: { es: 'Video · práctica · mock', en: 'Video · practice · mock' } },
    { cat: 'ap', tag: { es: 'A&P · Examen', en: 'A&P · Exam' }, title: { es: 'Exam Sprint', en: 'Exam Sprint' }, desc: { es: 'Mock written, oral y practical; rúbricas y preparación para DME.', en: 'Mock written, oral and practical; rubrics and DME preparation.' }, meta: { es: 'Cohorte · feedback', en: 'Cohort · feedback' } },
    { cat: 'english', tag: { es: 'Inglés', en: 'English' }, title: { es: 'Aviation English', en: 'Aviation English' }, desc: { es: 'Vocabulario técnico, lectura de manuales, entrevistas y comunicación de taller.', en: 'Technical vocabulary, manual reading, interviews and shop communication.' }, meta: { es: 'Online · speaking', en: 'Online · speaking' } },
    { cat: 'oem', tag: { es: 'OEM · Aviación ejecutiva', en: 'OEM · Business aviation' }, title: { es: 'Business Jet OEM', en: 'Business Jet OEM' }, desc: { es: 'Orientación a Gulfstream, Bombardier, Dassault, Embraer y Textron; ruta a factory training.', en: 'Orientation to Gulfstream, Bombardier, Dassault, Embraer and Textron; route to factory training.' }, meta: { es: 'Especialización', en: 'Specialization' } },
    { cat: 'oem', tag: { es: 'Aviónica', en: 'Avionics' }, title: { es: 'Avionics & Troubleshooting', en: 'Avionics & Troubleshooting' }, desc: { es: 'Sistemas, wiring, diagnóstico y aviónica de cabina ejecutiva.', en: 'Systems, wiring, troubleshooting and executive cabin avionics.' }, meta: { es: 'Video · casos', en: 'Video · cases' } },
    { cat: 'career', tag: { es: 'Empleo', en: 'Career' }, title: { es: 'Career Accelerator', en: 'Career Accelerator' }, desc: { es: 'CV técnico, entrevistas, portafolio, herramientas y preparación para empleadores.', en: 'Technical CV, interviews, portfolio, tools and employer preparation.' }, meta: { es: 'Mentoría · job board', en: 'Mentor · job board' } }
  ];

  const FAQ = [
    { q: { es: '¿Necesito experiencia previa?', en: 'Do I need previous experience?' }, a: { es: 'No para empezar la ruta. La FAA exige 18 meses por rating o 30 meses para A&P, o graduarse de una escuela Part 147. AV8R revisa tu caso y te dice qué falta.', en: 'Not to start the path. The FAA requires 18 months per rating or 30 months for A&P, or graduation from a Part 147 school. AV8R reviews your case and tells you what is missing.' } },
    { q: { es: '¿Es 100% online?', en: 'Is it 100% online?' }, a: { es: 'La teoría y la mentoría son online. La práctica, el oral/practical y el testing requieren un partner o DME autorizado. El video no reemplaza la práctica.', en: 'Theory and mentorship are online. Practice, oral/practical and testing require an authorized partner or DME. Video does not replace practice.' } },
    { q: { es: '¿Cuánto cuesta?', en: 'How much does it cost?' }, a: { es: 'Depende del cohorte, el país y el alcance. No publicamos precios que no estén confirmados. Pide una cotización por el chat o en la comunidad.', en: 'It depends on the cohort, country and scope. We do not publish unconfirmed prices. Request a quote in chat or in the community.' } },
    { q: { es: '¿AV8R certifica al técnico?', en: 'Does AV8R certify the technician?' }, a: { es: 'No. AV8R prepara y acompaña. La FAA emite el certificado A&P después de los exámenes y la experiencia requerida.', en: 'No. AV8R prepares and supports. The FAA issues the A&P certificate after the required tests and experience.' } },
    { q: { es: '¿El A&P me da visa de trabajo?', en: 'Does the A&P give me a work visa?' }, a: { es: 'No. El certificado A&P no otorga autorización de trabajo. Cualquier visa o empleo se gestiona por separado con un abogado de inmigración.', en: 'No. The A&P certificate does not grant work authorization. Any visa or employment is handled separately with an immigration attorney.' } },
    { q: { es: '¿Necesito inglés?', en: 'Do I need English?' }, a: { es: 'Sí. La FAA exige leer, escribir, hablar y entender inglés. Aviation English te prepara para manuales, entrevistas y taller.', en: 'Yes. The FAA requires reading, writing, speaking and understanding English. Aviation English prepares you for manuals, interviews and the shop.' } },
    { q: { es: '¿A&P + aviación ejecutiva?', en: 'A&P + business aviation?' }, a: { es: 'Sí. El A&P es la base; la aviación ejecutiva añade OEM, aviónica, interiores y servicio. Es la ruta de mayor especialización y salario.', en: 'Yes. A&P is the base; business aviation adds OEM, avionics, interiors and service. It is the highest-specialization, highest-pay path.' } },
    { q: { es: '¿Soy empleador?', en: 'I am an employer?' }, a: { es: 'Podemos explorar alianzas, prácticas y un pipeline de talento bilingüe. Escríbenos y revisamos el modelo.', en: 'We can explore alliances, internships and a bilingual talent pipeline. Write to us and we will review the model.' } }
  ];

  /* ------------------------------------------------------------------
     Page i18n
     ------------------------------------------------------------------ */
  const applyLang = lang => {
    state.lang = lang;
    document.documentElement.lang = lang;
    $$('[data-lang]').forEach(b => {
      const active = b.dataset.lang === lang;
      b.classList.toggle('is-active', active);
      b.setAttribute('aria-pressed', active ? 'true' : 'false');
    });
    $$('[data-i18n]').forEach(el => { const v = t(el.dataset.i18n, lang); if (v) el.textContent = v; });
    $$('[data-i18n-html]').forEach(el => { const v = t(el.dataset.i18nHtml, lang); if (v) el.innerHTML = v; });
    $$('[data-i18n-placeholder]').forEach(el => { const v = t(el.dataset.i18nPlaceholder, lang); if (v) el.placeholder = v; });
    renderRoute();
    renderPrograms();
    renderFaq();
    updateChatLang(lang, false);
    try { localStorage.setItem('av8r.lang', lang); } catch (_) {}
  };

  /* ------------------------------------------------------------------
     Route / programs / FAQ
     ------------------------------------------------------------------ */
  const renderRoute = () => {
    const wrap = $('#routeSteps');
    if (!wrap) return;
    wrap.innerHTML = ROUTE.map(s => {
      const copy = s[state.lang] || s.es;
      return `<article class="route-step"><span class="route-step__num">${s.n}</span><h3>${copy[0]}</h3><p>${copy[1]}</p><span class="route-step__out">${s.out[state.lang] || s.out.es}</span></article>`;
    }).join('');
  };

  const renderPrograms = () => {
    const grid = $('#programGrid');
    if (!grid) return;
    const list = state.filter === 'all' ? PROGRAMS : PROGRAMS.filter(p => p.cat === state.filter);
    grid.innerHTML = list.map(p => `
      <article class="program">
        <span class="program__tag">${p.tag[state.lang] || p.tag.es}</span>
        <h3>${p.title[state.lang] || p.title.es}</h3>
        <p>${p.desc[state.lang] || p.desc.es}</p>
        <span class="program__meta">${p.meta[state.lang] || p.meta.es}</span>
        <button class="program__link" type="button" data-open-chat="${state.lang === 'es' ? 'Quiero información sobre ' : 'I want information about '}${p.title[state.lang] || p.title.es}.">${state.lang === 'es' ? 'Consultar ruta' : 'Ask about this path'} <svg class="icon" aria-hidden="true"><use href="#i-arrow"></use></svg></button>
      </article>`).join('');
  };

  const renderFaq = () => {
    const list = $('#faqList');
    if (!list) return;
    list.innerHTML = FAQ.map((f, i) => `<details class="faq"${i === 0 ? ' open' : ''}><summary>${f.q[state.lang] || f.q.es}<span class="faq__plus" aria-hidden="true"></span></summary><p>${f.a[state.lang] || f.a.es}</p></details>`).join('');
  };

  $$('.filter').forEach(btn => btn.addEventListener('click', () => {
    state.filter = btn.dataset.filter;
    $$('.filter').forEach(b => b.classList.toggle('is-active', b === btn));
    renderPrograms();
  }));

  /* ------------------------------------------------------------------
     Header / menu / reveal
     ------------------------------------------------------------------ */
  const header = $('#header'), menuBtn = $('#menuBtn'), mobileMenu = $('#mobileMenu');
  const closeMenu = () => {
    if (!mobileMenu || mobileMenu.hidden) return;
    mobileMenu.hidden = true; document.body.classList.remove('is-locked');
    menuBtn.setAttribute('aria-expanded', 'false');
    const use = menuBtn.querySelector('use'); if (use) use.setAttribute('href', '#i-menu');
  };
  const openMenu = () => {
    mobileMenu.hidden = false; document.body.classList.add('is-locked');
    menuBtn.setAttribute('aria-expanded', 'true');
    const use = menuBtn.querySelector('use'); if (use) use.setAttribute('href', '#i-close');
  };
  if (menuBtn && mobileMenu) {
    menuBtn.addEventListener('click', () => mobileMenu.hidden ? openMenu() : closeMenu());
    $$('a', mobileMenu).forEach(a => a.addEventListener('click', closeMenu));
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMenu(); });
  }
  const onScroll = () => header.classList.toggle('is-scrolled', window.scrollY > 16);
  onScroll(); window.addEventListener('scroll', onScroll, { passive: true });

  const revealTargets = $$('.section__head, .start-card, .route-step, .program, .stat, .alliance, .faq, .community__card, .apply__form, .flight-card, .assistant__preview');
  if ('IntersectionObserver' in window && revealTargets.length) {
    document.body.classList.add('reveal-ready');
    revealTargets.forEach((el, i) => { el.setAttribute('data-reveal', ''); el.style.transitionDelay = `${Math.min(i % 4, 3) * 55}ms`; });
    const io = new IntersectionObserver(entries => entries.forEach(en => { if (en.isIntersecting) { en.target.classList.add('is-in'); io.unobserve(en.target); } }), { threshold: .1, rootMargin: '0px 0px -40px 0px' });
    revealTargets.forEach(el => io.observe(el));
  }

  /* ------------------------------------------------------------------
     Chat · AV8R Guide
     ------------------------------------------------------------------ */
  const CHAT = {
    es: {
      welcome: t('chat.welcome', 'es'),
      quick: [
        { label: 'Ruta FAA', prompt: '¿Cuál es la ruta FAA A&P?' },
        { label: 'Cursos', prompt: '¿Qué cursos tienen?' },
        { label: 'Empleo', prompt: '¿Cómo funciona el apoyo de empleo?' },
        { label: 'Hablar con humano', prompt: 'Quiero hablar con una persona de AV8R.' }
      ],
      fallback: 'Puedo orientarte en ruta FAA, cursos, comunidad, empleo y el siguiente paso. Si tu pregunta es sobre visa, precio exacto o una situación personal, la revisa un asesor humano. ¿Quieres que empecemos por la ruta o por los cursos?',
      intents: [
        { keys: ['visa', 'work authorization', 'trabajar en eeuu', 'trabajo en usa', 'autorizacion', 'green card', 'h-1b', 'm-1', 'relocation'], reply: 'Importante: el certificado A&P no otorga visa ni autorización de trabajo en EE. UU. La visa y el empleo se gestionan por separado con un abogado de inmigración. AV8R puede orientarte sobre la ruta técnica, no sobre inmigración.\n\n¿Quieres que veamos la ruta A&P o prefieres hablar con un asesor?' },
        { keys: ['precio', 'costo', 'cuanto', 'price', 'cost', 'tuition', 'pagar', 'inversion'], reply: 'No publicamos precios que no estén confirmados: dependen del cohorte, el país y el alcance. La forma correcta es pedir una cotización con AV8R y revisar qué incluye (video, mentoría, práctica, testing).\n\n¿Quieres que te conecte con el equipo?' },
        { keys: ['faa', 'requisito', 'elegibilidad', 'requirement', 'a&p', 'ap certificate', 'part 147'], reply: 'La FAA pide: 18 años, inglés (leer, escribir, hablar y entender), 18 meses de experiencia por rating o 30 meses para A&P (o escuela Part 147), y aprobar written, oral y practical con un DME autorizado.\n\nAV8R prepara; la FAA certifica. ¿Quieres revisar tu elegibilidad?' },
        { keys: ['ruta', 'empezar', 'cero', 'principiante', 'path', 'start', 'desde cero'], reply: 'La ruta AV8R es:\n01 Diagnóstico + inglés\n02 A&P General\n03 Airframe + Powerplant\n04 Práctica + testing (PSI/DME)\n05 OEM + empleo\n\nNo es un curso suelto: cada etapa tiene un entregable. ¿Estás empezando o ya tienes experiencia?' },
        { keys: ['curso', 'programa', 'course', 'program'], reply: 'El portal organiza: A&P General, Airframe, Powerplant, Exam Sprint, Aviation English, Business Jet OEM, Avionics y Career Accelerator. La malla exacta y la disponibilidad se confirman con AV8R.\n\n¿Te interesa A&P, inglés, OEM o empleo?' },
        { keys: ['ingles', 'english', 'idioma'], reply: 'La FAA exige inglés para el certificado. Aviation English trabaja vocabulario técnico, lectura de manuales, entrevistas y comunicación de taller. Si tu inglés no está listo, se nivela antes de la teoría.\n\n¿Quieres evaluar tu nivel?' },
        { keys: ['empleo', 'trabajo', 'job', 'career', 'colocacion', 'placement'], reply: 'AV8R construye alianzas con Part 147, Part 145/MRO, OEMs, FBOs y empleadores. El apoyo incluye portafolio, entrevistas y job board. No prometemos empleo ni visa: se mide y se trabaja caso a caso.\n\n¿Buscas tu primer empleo o quieres especializarte?' },
        { keys: ['oem', 'aviacion ejecutiva', 'business aviation', 'gulfstream', 'bombardier', 'dassault', 'embraer', 'textron'], reply: 'La aviación ejecutiva es la especialización: Gulfstream, Bombardier, Dassault, Embraer y Textron, más aviónica, interiores y servicio. El A&P es la base; el OEM es el siguiente nivel.\n\n¿Ya tienes A&P o estás empezando?' },
        { keys: ['comunidad', 'skool', 'community', 'miembros'], reply: 'AV8R School tiene una comunidad privada en Skool con 391 miembros, 9 cursos y 23 módulos (snapshot público). Incluye estudio, mentoría, guías FAST TRACK EN/ES y beneficios OEM.\n\n¿Quieres entrar a la comunidad o primero ver la ruta?' },
        { keys: ['empleador', 'empresa', 'contratar', 'employer', 'hire', 'talento'], reply: 'Si eres empleador, podemos explorar alianzas, prácticas y un pipeline de talento bilingüe. No es un job board automático todavía: se revisa el perfil y el modelo.\n\n¿Qué tipo de técnicos buscas?' },
        { keys: ['online', 'video', 'virtual', 'presencial'], reply: 'La teoría y la mentoría son online; la práctica, el oral/practical y el testing requieren un partner o DME autorizado. El video no reemplaza la práctica.\n\n¿Quieres ver la ruta completa?' },
        { keys: ['humano', 'persona', 'asesor', 'nestor', 'contacto', 'hablar'], reply: 'Puedes hablar con AV8R en la comunidad de Skool: https://www.skool.com/av8rschool. También puedes escribir a hello@av8rschool.com.\n\n¿Quieres que te deje el enlace o prefieres seguir con la ruta?' },
        { keys: ['hola', 'hello', 'hi', 'buenas'], reply: 'Hola. Soy AV8R Guide. Puedo ayudarte con la ruta FAA, los cursos, la comunidad o el siguiente paso. ¿Dónde estás hoy: empezando, con experiencia o ya A&P?' }
      ]
    },
    en: {
      welcome: t('chat.welcome', 'en'),
      quick: [
        { label: 'FAA path', prompt: 'What is the FAA A&P path?' },
        { label: 'Courses', prompt: 'What courses do you offer?' },
        { label: 'Jobs', prompt: 'How does career support work?' },
        { label: 'Talk to a human', prompt: 'I want to talk to a person at AV8R.' }
      ],
      fallback: 'I can guide you on the FAA path, courses, community, jobs and next step. If your question is about a visa, exact price or a personal case, a human advisor should review it. Shall we start with the path or the courses?',
      intents: [
        { keys: ['visa', 'work authorization', 'work in the us', 'green card', 'h-1b', 'm-1', 'relocation'], reply: 'Important: an A&P certificate does not grant a visa or work authorization in the U.S. Visa and employment are handled separately with an immigration attorney. AV8R can guide the technical path, not immigration.\n\nWould you like to see the A&P path or talk to an advisor?' },
        { keys: ['price', 'cost', 'tuition', 'how much', 'pay'], reply: 'We do not publish unconfirmed prices: they depend on the cohort, country and scope. The right step is to request a quote from AV8R and review what is included (video, mentorship, practice, testing).\n\nWould you like me to connect you with the team?' },
        { keys: ['faa', 'requirement', 'eligibility', 'a&p', 'ap certificate', 'part 147'], reply: 'The FAA requires: 18 years old, English (read, write, speak and understand), 18 months of experience per rating or 30 months for A&P (or a Part 147 school), and passing written, oral and practical tests with an authorized DME.\n\nAV8R prepares; the FAA certifies. Would you like to check your eligibility?' },
        { keys: ['path', 'start', 'zero', 'beginner', 'from scratch'], reply: 'The AV8R path is:\n01 Diagnosis + English\n02 A&P General\n03 Airframe + Powerplant\n04 Practice + testing (PSI/DME)\n05 OEM + employment\n\nIt is not a loose course: each stage has a deliverable. Are you starting or do you already have experience?' },
        { keys: ['course', 'program'], reply: 'The portal organizes: A&P General, Airframe, Powerplant, Exam Sprint, Aviation English, Business Jet OEM, Avionics and Career Accelerator. The exact curriculum and availability are confirmed with AV8R.\n\nAre you interested in A&P, English, OEM or career?' },
        { keys: ['english', 'language'], reply: 'The FAA requires English for the certificate. Aviation English covers technical vocabulary, manual reading, interviews and shop communication. If your English is not ready, we level it before theory.\n\nWould you like to assess your level?' },
        { keys: ['job', 'career', 'placement', 'employment'], reply: 'AV8R builds alliances with Part 147, Part 145/MRO, OEMs, FBOs and employers. Support includes portfolio, interviews and a job board. We do not promise a job or a visa: it is worked case by case.\n\nAre you looking for a first job or a specialization?' },
        { keys: ['oem', 'business aviation', 'gulfstream', 'bombardier', 'dassault', 'embraer', 'textron'], reply: 'Business aviation is the specialization: Gulfstream, Bombardier, Dassault, Embraer and Textron, plus avionics, interiors and service. A&P is the base; OEM is the next level.\n\nDo you already have A&P or are you starting?' },
        { keys: ['community', 'skool', 'members'], reply: 'AV8R School has a private Skool community with 391 members, 9 courses and 23 modules (public snapshot). It includes study, mentorship, FAST TRACK guides EN/ES and OEM benefits.\n\nWould you like to join the community or see the path first?' },
        { keys: ['employer', 'company', 'hire', 'talent'], reply: 'If you are an employer, we can explore alliances, internships and a bilingual talent pipeline. It is not an automatic job board yet: we review the profile and model.\n\nWhat kind of technicians are you looking for?' },
        { keys: ['online', 'video', 'virtual', 'in person'], reply: 'Theory and mentorship are online; practice, oral/practical and testing require an authorized partner or DME. Video does not replace practice.\n\nWould you like to see the full path?' },
        { keys: ['human', 'person', 'advisor', 'nestor', 'contact', 'talk'], reply: 'You can talk to AV8R in the Skool community: https://www.skool.com/av8rschool. You can also email hello@av8rschool.com.\n\nWould you like the link or shall we continue with the path?' },
        { keys: ['hello', 'hi', 'hey'], reply: 'Hi. I am AV8R Guide. I can help with the FAA path, courses, community or next step. Where are you today: starting, experienced, or already A&P?' }
      ]
    }
  };

  const normalize = s => (s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

  const localReply = (text, lang) => {
    const data = CHAT[lang] || CHAT.es;
    const n = normalize(text);
    const pathIntent = data.intents.find(i => i.keys.includes('ruta') || i.keys.includes('path'));
    const wantsPath = ['ruta', 'path', 'empezar', 'start', 'cero', 'zero', 'principiante', 'beginner'].some(k => n.includes(normalize(k)));
    if (wantsPath && pathIntent) return pathIntent.reply;
    const hit = data.intents.find(i => i.keys.some(k => n.includes(normalize(k))));
    return hit ? hit.reply : data.fallback;
  };

  const chatPanel = $('#chatPanel'), chatFab = $('#chatFab'), chatMessages = $('#chatMessages'), chatQuick = $('#chatQuick'), chatForm = $('#chatForm'), chatInput = $('#chatInput');
  let chatHistory = [];

  const isMobile = () => window.matchMedia('(max-width:760px)').matches;
  const syncFab = () => {
    if (!chatFab) return;
    const quiet = isMobile() && window.scrollY < 460;
    chatFab.classList.toggle('is-quiet', quiet && chatPanel.hidden);
  };
  syncFab();
  window.addEventListener('scroll', syncFab, { passive: true });
  window.addEventListener('resize', syncFab);

  const addMsg = (role, text) => {
    if (!chatMessages) return;
    const el = document.createElement('div');
    el.className = `chat-msg chat-msg--${role}`;
    el.textContent = text;
    chatMessages.appendChild(el);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  };

  const setTyping = on => {
    const existing = $('#chatTyping');
    if (on && !existing) {
      const el = document.createElement('div');
      el.id = 'chatTyping'; el.className = 'chat-msg chat-msg--bot chat-msg--typing';
      el.textContent = t('chat.typing', state.chatLang);
      chatMessages.appendChild(el); chatMessages.scrollTop = chatMessages.scrollHeight;
    } else if (!on && existing) existing.remove();
  };

  const renderQuick = () => {
    if (!chatQuick) return;
    const data = CHAT[state.chatLang] || CHAT.es;
    chatQuick.innerHTML = data.quick.map(q => `<button type="button" data-quick="${q.prompt.replace(/"/g, '&quot;')}">${q.label}</button>`).join('');
  };

  const updateChatLang = (lang, announce = true) => {
    state.chatLang = lang;
    $$('[data-chat-lang]').forEach(b => b.classList.toggle('is-active', b.dataset.chatLang === lang));
    if (chatInput) chatInput.placeholder = t('chat.placeholder', lang);
    const legal = $('.chat-legal');
    if (legal) legal.innerHTML = t('chat.legal', lang);
    renderQuick();
    if (announce && state.chatStarted) addMsg('bot', t('chat.langChanged', lang));
  };

  const openChat = async (prompt = '') => {
    if (!chatPanel) return;
    chatPanel.hidden = false; chatFab.hidden = true; chatFab.classList.remove('is-quiet'); document.body.classList.add('is-locked');
    updateChatLang(state.lang, false);
    if (!state.chatStarted) {
      state.chatStarted = true;
      const welcome = (CHAT[state.chatLang] || CHAT.es).welcome;
      addMsg('bot', welcome);
      chatHistory.push({ role: 'assistant', content: welcome });
    }
    if (prompt) {
      await sleep(120);
      sendChat(prompt);
    } else {
      chatInput.focus();
    }
  };

  const closeChat = () => {
    chatPanel.hidden = true; chatFab.hidden = false; document.body.classList.remove('is-locked');
    syncFab();
    if (!chatFab.classList.contains('is-quiet')) chatFab.focus();
  };

  const apiReply = async (text) => {
    if (location.protocol === 'file:') return null;
    try {
      const res = await fetch(CONFIG.api, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: chatHistory.slice(-8), lang: state.chatLang })
      });
      if (!res.ok) return null;
      const data = await res.json();
      return data && data.reply ? data.reply : null;
    } catch (_) { return null; }
  };

  const sendChat = async (raw) => {
    const text = (raw || '').trim();
    if (!text || state.chatBusy) return;
    state.chatBusy = true;
    addMsg('user', text);
    chatHistory.push({ role: 'user', content: text });
    chatInput.value = '';
    setTyping(true);
    const [api] = await Promise.all([apiReply(text), sleep(350)]);
    setTyping(false);
    const reply = api || localReply(text, state.chatLang);
    addMsg('bot', reply);
    chatHistory.push({ role: 'assistant', content: reply });
    state.chatBusy = false;
    chatInput.focus();
  };

  if (chatFab) chatFab.addEventListener('click', () => openChat());
  $('#chatClose') && $('#chatClose').addEventListener('click', closeChat);
  chatForm && chatForm.addEventListener('submit', e => { e.preventDefault(); sendChat(chatInput.value); });
  chatQuick && chatQuick.addEventListener('click', e => { const b = e.target.closest('[data-quick]'); if (b) sendChat(b.dataset.quick); });
  $$('[data-chat-lang]').forEach(b => b.addEventListener('click', () => updateChatLang(b.dataset.chatLang)));
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && chatPanel && !chatPanel.hidden) closeChat(); });

  /* ------------------------------------------------------------------
     Open chat from any CTA
     ------------------------------------------------------------------ */
  document.addEventListener('click', e => {
    const opener = e.target.closest('[data-open-chat]');
    if (opener) { e.preventDefault(); openChat(opener.dataset.openChat || ''); return; }
    const start = e.target.closest('[data-start]');
    if (start) {
      const prompts = state.lang === 'en' ? {
        beginner: 'I am starting from zero. What is my path?',
        experience: 'I have maintenance experience. How should I enter the A&P path?',
        ap: 'I am already A&P. How do I move into business aviation or OEM?',
        employer: 'I am an employer looking for bilingual technical talent.'
      } : {
        beginner: 'Estoy empezando desde cero. ¿Cuál es mi ruta?',
        experience: 'Tengo experiencia en mantenimiento. ¿Cómo me conviene entrar al A&P?',
        ap: 'Ya soy A&P. ¿Cómo paso a aviación ejecutiva u OEM?',
        employer: 'Soy empleador y busco talento técnico bilingüe.'
      };
      openChat(prompts[start.dataset.start] || (state.lang === 'en' ? 'I want information about AV8R.' : 'Quiero información sobre AV8R.'));
    }
  });

  /* ------------------------------------------------------------------
     Language buttons
     ------------------------------------------------------------------ */
  $$('[data-lang]').forEach(b => b.addEventListener('click', () => applyLang(b.dataset.lang)));

  /* ------------------------------------------------------------------
     Form
     ------------------------------------------------------------------ */
  const form = $('#applyForm'), status = $('#formStatus');
  if (form) {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const name = $('#name').value.trim(), email = $('#email').value.trim(), country = $('#country').value.trim(), goal = $('#goal').value, message = $('#message').value.trim(), consent = $('#consent').checked;
      if (!name || !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) || !consent) {
        status.textContent = t('form.error'); status.className = 'form-status is-error'; return;
      }
      const subject = `AV8R application · ${goal} · ${name}`;
      const body = `Name: ${name}\nEmail: ${email}\nCountry: ${country}\nGoal: ${goal}\nMessage: ${message}\n\nConsent: yes\nSent from av8r-web prototype.`;
      status.textContent = t('form.sending'); status.className = 'form-status is-ok';
      window.location.href = `mailto:${CONFIG.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      setTimeout(() => { status.textContent = t('form.ok'); }, 600);
    });
  }

  /* ------------------------------------------------------------------
     Init
     ------------------------------------------------------------------ */
  const year = $('#year'); if (year) year.textContent = String(new Date().getFullYear());
  let saved = 'es';
  try { saved = localStorage.getItem('av8r.lang') || 'es'; } catch (_) {}
  applyLang(saved === 'en' ? 'en' : 'es');
  updateChatLang(state.lang, false);
  console.info('[AV8R] Prototipo. Datos públicos de Skool; reemplazar email/CRM y validar FAA/visa/ITAR antes de publicar.');
})();
